#include <stdio.h>

int main() {
    puts(
        "Copyright @ Muhammad Bryan Farras - 2306230975\n"
        "-Use the shell at your own risk...\n"
        "List of Commands supported:\n"
        ">print {something} : Print something\n"
        ">exit : Exit the shell\n"
        ">help : Show all commands in shell\n"
        ">itungwoi {add|sub|mul|div} num1 num2 : Do some Calculation\n"
        ">buatdong {filename} {content} : Write to a file\n"
        ">bacadong {filename} : Read from a file\n"
        ">rahasiabanget {filename} : Write to a file (encrypted)\n"
        ">bacapikiran {filename} : Read from a file (encrypted)\n"
        ">kompres {filename} {file1} {file2} {file...}\n"
        ">lihat: ls direktori\n"
        ">dimana: kayak pwd\n"
        ">hapusdong: menghapus file\n"
        ">bukain: unzip file\n"
        ">bersihindong: bersihin terminal\n"
    );
    return 0;
}


